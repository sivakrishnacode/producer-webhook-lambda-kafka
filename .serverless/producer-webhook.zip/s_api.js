
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'sivakrishna',
  applicationName: 'afflr',
  appUid: '0LF28psQL5fhpRVPZk',
  orgUid: 'bb59721e-9775-48d5-9b22-4da8cad82a00',
  deploymentUid: 'd7863388-fc1a-4603-bfd2-b58f9b909f6f',
  serviceName: 'producer-webhook',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'producer-webhook-dev-api', timeout: 6 };

try {
  const userHandler = require('./dist/serverless.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}