
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'sivakrishna',
  applicationName: 'afflr',
  appUid: '0LF28psQL5fhpRVPZk',
  orgUid: 'bb59721e-9775-48d5-9b22-4da8cad82a00',
  deploymentUid: '98b145da-e2c0-4a62-b746-acd2c0631660',
  serviceName: 'producer-webhook',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'producer-webhook-dev-api', timeout: 6 };

try {
  const userHandler = require('./dist/serverless.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}